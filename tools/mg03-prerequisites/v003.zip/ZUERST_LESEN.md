# MG03 – lokal ergänztes Prüfpaket E70 / V003

**Statisch geprüft; sämtliche nativen Fälle NOT_RUN. MG02 und MG03 bleiben offen.** Keine neue Merge-, CI-, Workflow-, Push-, Deploy- oder externe Providerfreigabe. Dieses Paket erweitert E48 nach E68; es ist kein vollständiges Chat-Übergabepaket. Originale Migrationen und ursprüngliches ZIP V001 bleiben unverändert.

1. `python3 run.py` ist ausschließlich eine Integritätsprüfung, ohne Runtime, Datenbank, Netzwerk oder Git-Aufruf.
2. `python3 -m unittest test_static` prüft ausschließlich Fehler-/Sicherheitsgrenzen des Pakets und Ergebnisparsers. Keine nativen Produktfälle.
3. `run.py --execute --repo ... --tls-dir ...` ist ein vorbereiteter, **noch nicht nativ geprüfter** Ausführungszweig für einen später separat beauftragten isolierten Lauf. Heute wurde er nicht gestartet. Keine Automation oder Workflowdatei in diesem Paket.

## 1. Quellbindung

Repository PROVIDE-Webdesign/Provide-bestellsystem. main c3530b2dacdb814cfc2cc47664ab23b11ce878d0; Kandidat cbc78a2240eba05840b6cd712c89025bb6377635 / Tree ddb303c30e0346194cbd28eb5d64e4e0f8cb3310. 26 Baseline- und 20 Ergänzungsmigrationen, Original-Bytes und Git-Blob-IDs im Manifest. V001 SHA-256 7cee6b2bd81ccb6c928c963d02e8bcafcad8206acf8b2f718017a443bd859ef2. `source-index.json` bindet gelesene technische Quellen; die vollständige Produkt-Checkout-Version bleibt eine Voraussetzung der späteren Ausführung, keine Ersatzimplementierung im Paket.

## 2. Ergänzungen

1. Fünf Bestandsbestellungen: vier originale Pickup-Aufträge, davon einer captured und einer refunded; eine zusätzliche Delivery-Bestellung samt Gebühren-/Adress-/Kontakt-Snapshot. Zahlungszustände über originale Baseline-Funktionen mit synthetischen Providerereignissen; kein externer Stripe-Aufruf und kein ausgeschalteter Trigger.
2. Zweite Location im gleichen Mandanten; zwei Mandanten unverändert. Native Auth/MFA statt SQL-erfundener Faktoren/Sitzungen im Ausführungszweig. Bestehende Baseline-User bleiben synthetische Testidentitäten.
3. Exakte Versionslisten 26→46, Erweiterung ohne Reset/Reseed, No-op-Wiederholung und SQL-/TAP-Daten-/Rechteprüfungen. Ein dynamischer TAP-Plan muss vollständig sein; Fehler, Skip/TODO, fehlende, doppelte oder falsch gebundene Ergebnisse verhindern einen Erfolg.
4. Baseline- und Nachupgrade-Restore in einem getrennten eigenen Supabase-Projekt, gleiche Image-Digests, eigenes Volume, nacheinander gestartete Stacks. Neue aktuelle Restore-Snapshots trennen legitime Prüfmutationen nach Upgrade vom unverändert zu prüfenden alten Migrationsbestand.
5. Rollen, Mitgliedschaften, Eigentümer, Grants, RLS/Policies und Funktionen gesondert vergleichen. pg_dump enthält keine globalen Rollen; der identische lokale Supabase-Bootstrap stellt sie bereit und der Vergleich muss Gleichheit bestätigen. Gleiche kurzlebige Auth-Signierdatei/JWT-Konfiguration für beide Projekte; keine Remote-Secrets.
6. Native lokale Auth-/MFA-, PostgREST-, Produkt-Worker- und private Realtime-Probes; Viewer, Fremdmandant, fremde Location, Session-/Zugriffsentzug, Sperre, alte API-Replays und neue Realtime-Verbindung nach Entzug. Erlaubte Owner/Manager/Kitchen-Fälle und verbotene Rohschreibrechte werden geprüft.
7. HTTPS/WSS am lokalen Adapter. Unveränderter asymmetrischer Produkt-Tokenverifier; keine gefälschte Identity-Injektion. Echte lokale MFA-Tokens werden geprüft. Zahlungsanbieter, Einladungs-/E-Mail-Versand und externe Fetchziele sind gesperrt. Der Checkout-Attestierungs-/Challengeadapter ist ausdrücklich synthetisch.
8. R12-01 mit produktivem MenuEditor in Chromium/Firefox/WebKit am migrierten Bestand: reale Menü-API, private lokale Änderungsnotiz, Sessionentzug, echte 401/403, leeres Editorformular. UI-Transport ist ein lokaler Testgateway mit serverseitig gehaltenem Token; kein Beleg für produktives SSR, echte Login-Cookies oder Geräteabnahme.

## 3. Voraussetzungen vor einem späteren Lauf

Nur eine neue wegwerfbare Linux-x64-VM verwenden, kein bestehendes Produkt-/Nutzer-Setup. Docker lauffähig; CLI 2.117.0; Node 24; pnpm 11.19.0; PostgreSQL 15. CLI-Help wird vor Start gelesen. Kandidaten-Checkout unverändert am genannten Head/Tree, vollständige Dependencies gemäß unverändertem Lockfile vorhanden, @provide/contracts gebaut, drei Browser und Systemabhängigkeiten installiert. Der Runner installiert nichts und ruft kein deploy-Skript auf.

Eigene TLS-Test-CA und damit signiertes Zertifikat mit SAN IP:127.0.0.1 bereitstellen (`ca.pem`, `cert.pem`, `key.pem`); Schlüsseldateien privat halten. CA ausschließlich in dieser wegwerfbaren VM und deren Browserprofilen vertrauen. Runner prüft Node sowie alle drei Browser mit strenger TLS-Prüfung **vor** dem ersten Stackstart; keine Zertifikatsprüfung abschalten. Das Einrichten dieses Vertrauens und der konkreten CI-VM ist noch ein späterer Umgebungsschritt, kein heutiges Ergebnis.

Freie Ports 54320/54321/54322/54324/4319, mindestens 8-GB-Klasse und 10 GiB freier Speicher. Tatsächliche Portbindungen jedes Containers müssen 127.0.0.1 sein. Nach Imagevorbereitung reichen Ressourcen möglicherweise nicht mehr; dann abbrechen. Eigene Netzwerk-/Projekt-IDs werden erzeugt; fremde Projekte nicht lesen, stoppen oder entfernen.

## 4. Reihenfolge und Nachweise

Preflight/CA → Stack A mit main → Basis-Fixture → echte lokale Auth/MFA → Legacy-Aufträge/Zahlungen/Delivery → unveränderlichen Baseline-Snapshot aufnehmen → Baseline-Sicherung/Restore B/Dienstprüfung → A ohne Reset um 20 Originalmigrationen erweitern → Altdaten/TAP/Rechte/No-op → native Dienste/Browser → aktueller Nachupgrade-Snapshot/Sicherung/Restore B → Advisors → Belegsicherung/gezieltes Cleanup.

`cases.json` legt erwartete native Fall-IDs je Phase fest. Alle Gruppen UP-01–08 werden im Ablauf abgebildet; eine Gruppenzuordnung ist kein selbständiger PASS. Der native Runner endet auch bei grünen Fällen höchstens mit `NATIVE_CASES_COMPLETED_REVIEW_REQUIRED`: Advisorbefunde und vollständige Quellen-/Laufgrenzen müssen anschließend eigenständig bewertet werden. MG03 wird nie automatisch geschlossen.

Logs enthalten überwiegend Exitcodes/Hashes, keine Ausgabe des Supabase-Key-Status. Private Auth-/Context-/Dumpdateien nur im Modus 0600 innerhalb eines 0700-Arbeitsverzeichnisses; Cleanup entfernt sie und eigene Stackverzeichnisse. `evidence/` darf keine Token, TOTP-Secrets oder Dumps enthalten. TLS-Dateien sind von der späteren VM-Vorbereitung bereitgestellt und bleiben deren Cleanup-Aufgabe; der Runner löscht keine fremden TLS-Pfade.

## 5. Nachweisgrenzen und Pausen

Syntaxprüfung mit pglast 7.8/PostgreSQL-Parser 17.4 ist kein PostgreSQL-15-, RLS-, Auth-, TLS- oder Restore-Lauf. JavaScript `--check` und Python-Offline-Tests bestätigen keine aufgelösten Produktimporte oder native Dienstfähigkeit. Konkrete Adapter-/Runtime-/Schemasemantik kann erst beim späteren Lauf bestehen oder fehlschlagen; Fehler offen auswerten, nicht mit Reset oder Fake-Antworten überdecken.

Produktive Dashboard-/Storefront-SSR und echte Cookie-/Login-Flows, reale Edge-/WAF-/Turnstile-, direkte externe Authlimits, Last/Shared NAT, Datenschutzfreigabe und physische Geräte sind **nicht** durch dieses Paket abgenommen. F01–F03 und O3-T51–T56 bleiben pausiert. R12 ist hier ein zusätzlicher auf den migrierten Bestand gebundener automatisierter Komponentenfall; bestehende umfangreiche E39/CI184-R12-Varianten bleiben unter ihren ursprünglichen Grenzen erhalten. Keine neue Pflicht zu ihrer vollständigen Wiederholung aus diesem Paket ableiten.

MG02 bleibt bis zum E67-Bestandsabschluss offen. MG04–MG08, E40, Produkt-/Pilot-/Deploymentgrenzen bleiben erhalten. Technische Planerfüllung 69,477513227513 %, 82 Bewertungen unverändert. Für native Ausführung ist ein neuer begrenzter Auftrag mit konkret geeigneter isolierter Umgebung notwendig.

## 6. E70 – Nachkontrolle der Wiederaufnahme

V003 ersetzt V002 für eine spätere Ausführung; V001/V002 bleiben historische unveränderte Pakete. Keine neue native Ausführung oder Gatefreigabe.

1. Ergebnisdateien und Befehlsbelege getrennt: native Ergebnisse verbleiben unter evidence/native-*.json; nummerierte Befehlsbelege und geeignete bereinigte TAP-/Advisor-Ausgaben stehen unter evidence/commands/. Weder Ergebnisse noch wiederholte Befehle werden durch denselben Dateinamen überschrieben.
2. Restore behält das durch template0/initdb vorhandene public-Schema und prüft dessen Existenz. PostgreSQL 15 pg_dump setzt es bei einem vollständigen logischen Dump voraus und erstellt es nicht neu. Der unzutreffende drop-schema-Schritt aus V002 entfällt.
3. Unabhängiges Aufräumen: jeder eigene Container-/Volume-/Netzwerk-/Dateischritt wird auch nach vorherigem Fehler versucht, Fehler bleiben sichtbar. Browser, Realtime, Vite/TLS und SQL schließen unabhängig; Cleanup-FAIL verhindert einen nativen PASS. Fehlgeschlagene sichere Prüfkommandos behalten bereinigte Diagnosebelege; Timeouts erhalten einen eigenen Fehlbeleg.
4. Docker-Ziel vor info/start prüfen: nur ein lokaler Unix-Socket; Remote-Kontexte/DOCKER_HOST per TCP/SSH oder explizite DOCKER_CONTEXT-Overrides stoppen. Nach Prüfung wird derselbe Socket für alle Runner-Kommandos verwendet, ohne den Nutzerkontext umzustellen.
5. Neue gezielte Offline-Regressionsprüfungen für diese Übergänge. Sie simulieren Befehlsrückgaben/Aufräumfehler und sind ausdrücklich keine Datenbank-, TLS-, Auth-, Browser- oder Restoreausführung. Native Timeouts/Prozess- und Ressourcenfreiheit müssen im späteren isolierten Lauf tatsächlich nachgewiesen werden.
