"""MG03 offline checks and separately authorized disposable Docker runner. No remote targets."""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,socket,subprocess,tempfile,time

HERE=Path(__file__).resolve().parent
HEAD='cbc78a2240eba05840b6cd712c89025bb6377635'
TREE='ddb303c30e0346194cbd28eb5d64e4e0f8cb3310'
MAIN='c3530b2dacdb814cfc2cc47664ab23b11ce878d0'
EXCLUDES='studio,storage-api,imgproxy,postgres-meta,edge-runtime,logflare,vector,supavisor'

def require(condition,message):
    if not condition: raise ValueError(message)

def docker_socket(context,env):
    require(not env.get('DOCKER_CONTEXT'),'Explicit DOCKER_CONTEXT override is outside this local runner contract')
    endpoint=env.get('DOCKER_HOST') or context['Endpoints']['docker']['Host']
    require(endpoint.startswith('unix:///') and not any(x in endpoint for x in ['?', '#', '\n']),'Only a local Unix Docker socket is allowed')
    return endpoint

def integrity(directory=HERE):
    m=json.loads((directory/'manifest.json').read_text())
    expected={x['path'] for x in m['files']}
    actual={p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='manifest.json'}
    require(actual==expected,'Payload set mismatch')
    for row in m['files']:
        path=directory/row['path']
        require(not path.is_symlink() and '..' not in Path(row['path']).parts,'Unsafe payload path')
        b=path.read_bytes()
        require(len(b)==row['size'] and hashlib.sha256(b).hexdigest()==row['sha256'],'Hash/size mismatch: '+row['path'])
    require(len(list((directory/'baseline').glob('*.sql')))==26,'26 baseline SQL required')
    require(len(list((directory/'additions').glob('*.sql')))==20,'20 additions required')
    require(m['main']==MAIN and m['head']==HEAD and m['tree']==TREE,'Pin mismatch')
    return m

def tap_ok(text):
    lines=text.splitlines()
    require(not any(re.match(r'^\s*(not ok\b|Bail out!)',x,re.I) for x in lines),'TAP failure')
    tests=[x for x in lines if re.match(r'^ok\s+\d+\b',x)]
    plans=[int(x.split('..')[1].strip()) for x in lines if re.fullmatch(r'1\.\.\d+',x.strip())]
    require(len(plans)==1 and plans[0]>0 and len(tests)==plans[0],'Missing/mismatched TAP plan')
    require(not any(re.search(r'#\s*(SKIP|TODO)\b',x,re.I) for x in tests),'Skipped/TODO required case')
    require([int(re.match(r'ok\s+(\d+)',x).group(1)) for x in tests]==list(range(1,plans[0]+1)),'TAP numbering mismatch')
    return len(tests)

def check_results(result,required,run_id,stage):
    require(result.get('cleanup',{}).get('status')=='PASS','Native resource cleanup incomplete')
    require(result.get('status')=='PASS' and result.get('head')==HEAD,'Native summary/head mismatch')
    require(result.get('forbidden_requests')==0 and result.get('native_database_host')=='127.0.0.1','Missing isolation proof')
    require(result.get('run_id')==run_id and result.get('stage')==stage,'Unbound native result')
    rows=result.get('cases',[])
    require(len({r['id'] for r in rows})==len(rows),'Duplicate native case')
    require({r['id'] for r in rows}==set(required),'Missing/unexpected native cases')
    require(all(r['status']=='PASS' for r in rows),'Native case not PASS')

class Runner:
    def __init__(self,repo,tls):
        self.repo=repo.resolve();self.tls=tls.resolve()
        self.work=Path(tempfile.mkdtemp(prefix='provide-mg03-'))
        os.chmod(self.work,0o700)
        self.run_id=self.work.name;self.network=self.run_id+'-net'
        self.stacks={};self.started=set();self.results=[];self.network_created=False;self.runtime_images=None
        self.evidence=self.work/'evidence';self.evidence.mkdir(mode=0o700)
        self.command_evidence=self.evidence/'commands';self.command_evidence.mkdir(mode=0o700);self.command_number=0
    def command(self,args,name,cwd=None,data=None,timeout=180,capture=True):
        env={k:v for k,v in os.environ.items() if not re.search(r'(SUPABASE|STRIPE|CLOUDFLARE|RENDER|DATABASE_|TEST_|NODE_OPTIONS|AWS_|AZURE_|GOOGLE_|CF_|GITHUB_TOKEN|GH_TOKEN)',k)}
        if hasattr(self,'local_docker_socket'):
            env['DOCKER_HOST']=self.local_docker_socket;env.pop('DOCKER_CONTEXT',None)
        env['NODE_EXTRA_CA_CERTS']=str(self.tls/'ca.pem')
        self.command_number+=1
        receipt=self.command_evidence/(f'{self.command_number:06d}-'+name)
        try:
            p=subprocess.run(args,cwd=cwd,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=timeout)
        except subprocess.TimeoutExpired as e:
            if capture:receipt.with_suffix('.json').write_text(json.dumps({'args':args,'exit':None,'status':'TIMEOUT','timeout_seconds':timeout}))
            raise ValueError('Command timed out: '+name) from e
        # Do not retain raw auth keys, JWTs, passwords or full pg_dump stdout as public evidence.
        if capture:
            receipt.with_suffix('.json').write_text(json.dumps({'args':args,'exit':p.returncode,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}))
        if capture and (name in ['post-upgrade-tap','rights-tap','advisors'] or name.startswith(('versions-','pg-version-'))):
            for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:
                text=data.decode('utf8',errors='replace')
                text=re.sub(r'[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}','[REDACTED_JWT]',text)
                text=re.sub(r'postgresql://[^@\s]+@','postgresql://[REDACTED]@',text)
                Path(str(receipt)+'.'+stream).write_text(text)
        require(p.returncode==0,'Command failed: '+name+'; no automatic PASS')
        return p.stdout
    def preflight(self):
        require(shutil.which('docker') and shutil.which('supabase'),'Docker and Supabase CLI required')
        require(self.command(['supabase','--version'],'cli').decode().strip().splitlines()[0]=='2.117.0','CLI pin differs')
        context=json.loads(self.command(['docker','context','inspect'],'docker-context'))
        require(len(context)==1,'Ambiguous Docker context')
        self.local_docker_socket=docker_socket(context[0],os.environ)
        self.command(['docker','info'],'docker')
        require(self.command(['node','--version'],'node').decode().startswith('v24.'),'Node 24 required')
        require(self.command(['pnpm','--version'],'pnpm').decode().strip()=='11.19.0','pnpm 11.19.0 required')
        require(self.command(['git','rev-parse','HEAD'],'head',self.repo).decode().strip()==HEAD,'Candidate HEAD differs')
        require(self.command(['git','rev-parse','HEAD^{tree}'],'tree',self.repo).decode().strip()==TREE,'Candidate tree differs')
        require(not self.command(['git','status','--porcelain','--untracked-files=normal'],'clean',self.repo).strip(),'Candidate worktree must be clean')
        for group,ref in [('baseline',MAIN),('additions',HEAD)]:
            for f in (HERE/group).glob('*.sql'):
                actual=self.command(['git','show',ref+':supabase/migrations/'+f.name],'git-sql-'+f.stem,self.repo)
                require(actual==f.read_bytes(),'Original SQL differs from pinned checkout')
        for f in ['ca.pem','cert.pem','key.pem']:
            require((self.tls/f).is_file() and not (self.tls/f).is_symlink(),'Local TLS files required: '+f)
        # Validate real trust externally in every browser; no TLS verification bypass exists here.
        require(self.command(['git','merge-base','--is-ancestor',MAIN,HEAD],'ancestry',self.repo)==b'','Pinned main not ancestor')
        for cmd in [['supabase','start','--help'],['supabase','stop','--help'],['supabase','migration','up','--help'],['supabase','db','advisors','--help']]:self.command(cmd,'help-'+cmd[-2])
        for port in [54320,54321,54322,54324,4319]:
            with socket.socket() as s:s.bind(('127.0.0.1',port))
        require(shutil.disk_usage(self.work).free>=10*1024**3,'At least 10 GiB free disk required')
        mem=int(re.search(r'MemTotal:\s+(\d+)',Path('/proc/meminfo').read_text()).group(1))*1024
        require(mem>=7*1024**3,'8-GB-class VM required')
        self.command(['openssl','verify','-CAfile',str(self.tls/'ca.pem'),str(self.tls/'cert.pem')],'tls-chain')
        self.command(['node',str(HERE/'tls-preflight.mjs'),str(self.repo),str(self.tls)],'tls-browser-preflight',timeout=120)
        signing=self.work/'shared-signing-keys.json'
        script="const c=require('node:crypto'),f=require('node:fs');const k=c.generateKeyPairSync('ec',{namedCurve:'prime256v1'}).privateKey.export({format:'jwk'});f.writeFileSync(process.argv[1],JSON.stringify([{...k,kid:c.randomUUID(),alg:'ES256',use:'sig',key_ops:['sign','verify']}]),{mode:0o600})"
        self.command(['node','-e',script,str(signing)],'generate-disposable-auth-key')
        import secrets
        self.jwt_secret=secrets.token_hex(32)
        self.command(['docker','network','create','-o','com.docker.network.bridge.host_binding_ipv4=127.0.0.1',self.network],'network');self.network_created=True
        for kind in ['a','b']:
            d=self.work/kind;(d/'supabase/migrations').mkdir(parents=True)
            cfg=(HERE/'config.toml').read_text().replace('provide-bestellsystem-local',self.run_id+'-'+kind)
            cfg=cfg.replace('[auth]','[auth]\nsigning_keys_path = '+json.dumps(str(signing))+'\njwt_secret = '+json.dumps(self.jwt_secret))
            cfg='[api]\nport = 54321\n\n[inbucket]\nport = 54324\n\n'+cfg
            (d/'supabase/config.toml').write_text(cfg)
            self.stacks[kind]={'dir':d,'id':self.run_id+'-'+kind,'container':'supabase_db_'+self.run_id+'-'+kind}
        for f in (HERE/'baseline').glob('*.sql'):shutil.copyfile(f,self.stacks['a']['dir']/'supabase/migrations'/f.name)
    def start(self,k):
        self.started.add(k)
        self.command(['supabase','start','--network-id',self.network,'-x',EXCLUDES],'start-'+k,self.stacks[k]['dir'],timeout=600)
        ids=self.command(['docker','ps','-aq','--filter','label=com.supabase.cli.project='+self.stacks[k]['id']],'container-ids-'+k).decode().split()
        require(ids,'Own project containers missing')
        detail=json.loads(self.command(['docker','inspect',*ids],'inspect-'+k))
        for obj in detail:
            for binds in (obj['HostConfig'].get('PortBindings') or {}).values():
                for binding in binds or []:require(binding.get('HostIp')=='127.0.0.1','Non-loopback port binding')
        current_images=sorted(o['Image'] for o in detail)
        if self.runtime_images is None:self.runtime_images=current_images
        require(current_images==self.runtime_images,'Runtime image digest changed')
        pg=self.query(k,'show server_version_num','pg-version-'+k).decode().strip()
        require(150000<=int(pg)<160000,'Actual PG major differs from 15')
        (self.evidence/('images-'+k+'.json')).write_text(json.dumps([{'name':o['Name'],'image':o['Image']} for o in detail]))
    def stop(self,k):
        self.command(['supabase','stop','--project-id',self.stacks[k]['id']],'stop-'+k,self.stacks[k]['dir'],timeout=180)
    def query(self,k,text,name):
        return self.command(['docker','exec','-i',self.stacks[k]['container'],'psql','-X','-U','postgres','-d','postgres','-At','-v','ON_ERROR_STOP=1'],name,data=text.encode())
    def sql(self,k,file,name):return self.query(k,(HERE/file).read_text(),name)
    def versions(self,k,count):
        expected=sorted(f.name.split('_')[0] for f in (HERE/'baseline').glob('*.sql'))
        if count==46:expected+=sorted(f.name.split('_')[0] for f in (HERE/'additions').glob('*.sql'))
        actual=self.query(k,'select version from supabase_migrations.schema_migrations order by version','versions-'+k).decode().split()
        require(actual==sorted(expected),'Exact migration ledger mismatch')
    def context(self,k,stage):
        raw=json.loads(self.command(['supabase','status','--output','json'],'private-status-'+k,self.stacks[k]['dir'],capture=False))
        for key in ['API_URL','DB_URL']:require(raw[key].startswith(('http://127.0.0.1:','postgresql://postgres:postgres@127.0.0.1:')),'Unexpected stack URL')
        context={'run_id':self.run_id,'stage':stage,'repo':str(self.repo),'tls':str(self.tls),'work':str(self.work),'state':str(self.work/('auth-'+k+'.json')),'database':raw['DB_URL'],'url':raw['API_URL'],'anon':raw['ANON_KEY'],'admin':raw['SERVICE_ROLE_KEY'],'output':str(self.evidence/('native-'+stage+'.json'))}
        p=self.work/'context.json';p.write_text(json.dumps(context));os.chmod(p,0o600)
        return p
    def native(self,k,stage):
        context=self.context(k,stage)
        self.command(['node',str(HERE/'native.mjs'),str(context)],'native-'+stage,timeout=600)
        result=json.loads((self.evidence/('native-'+stage+'.json')).read_text())
        required=json.loads((HERE/'cases.json').read_text())['native_stages'][stage]
        check_results(result,required,self.run_id,stage)
        return result
    def restore(self,label,count):
        a=self.stacks['a'];b=self.stacks['b']
        self.versions('a',count)
        self.sql('a','capture_restore.sql','capture-restore-'+label)
        catalog=self.sql('a','snapshot_catalog.sql','catalog-source-'+label)
        dump=self.command(['docker','exec',a['container'],'pg_dump','-U','postgres','-d','postgres','-Fc'],'dump-'+label,timeout=180,capture=False)
        dumpfile=self.work/(label+'.dump');dumpfile.write_bytes(dump);os.chmod(dumpfile,0o600)
        self.stop('a');self.start('b')
        # Same pinned Supabase bootstrap supplies global roles. Compare, never claim pg_dump contains them.
        for k in ['a','b']:
            require((self.evidence/('images-'+k+'.json')).exists(),'Missing runtime binding')
        images=lambda k:sorted(x['image'] for x in json.loads((self.evidence/('images-'+k+'.json')).read_text()))
        require(images('a')==images('b'),'Restore runtime image set differs')
        own=self.command(['docker','ps','-q','--filter','label=com.supabase.cli.project='+b['id']],'b-services').decode().split()
        dbid=self.command(['docker','inspect','--format','{{.Id}}',b['container']],'b-db').decode().strip()
        services=[i for i in own if not dbid.startswith(i)]
        if services:self.command(['docker','stop',*services],'pause-b-services')
        self.command(['docker','exec',b['container'],'psql','-X','-U','postgres','-d','template1','-v','ON_ERROR_STOP=1','-c',"select pg_terminate_backend(pid) from pg_stat_activity where datname='postgres' and pid<>pg_backend_pid()"],'terminate-b')
        self.command(['docker','exec',b['container'],'dropdb','-U','postgres','postgres'],'drop-own-empty-target')
        self.command(['docker','exec',b['container'],'createdb','-U','postgres','-T','template0','postgres'],'create-own-target')
        # PostgreSQL 15 pg_dump expects initdb's public schema in a template0 target.
        require(self.query('b',"select count(*) from pg_namespace where nspname='public'",'target-public-schema').strip()==b'1','Fresh target is missing public schema')
        self.command(['docker','exec','-i',b['container'],'pg_restore','-U','postgres','--exit-on-error','-d','postgres'],'restore-'+label,data=dump,timeout=240)
        require(self.sql('b','snapshot_catalog.sql','catalog-restored-'+label)==catalog,'Restore owner/role/grant/policy catalog differs')
        require(self.query('b',"select bool_and(upgrade_evidence.legacy_rows_match(schema_name,table_name,columns_before,pk,rows_before)) from upgrade_evidence.restore_snapshot",'restore-legacy-'+label).strip()==b't','Restore legacy data mismatch')
        self.versions('b',count)
        if services:self.command(['docker','start',*services],'resume-b-services')
        self.native('b','restore-'+label)
        self.stop('b')
        (self.work/'auth-b.json').unlink(missing_ok=True)
        # Remove only B volume before next restore cycle. Source A volume preserved.
        volumes=self.command(['docker','volume','ls','-q','--filter','label=com.supabase.cli.project='+b['id']],'b-volumes').decode().split()
        if volumes:self.command(['docker','volume','rm',*volumes],'remove-b-volumes')
        self.start('a')
        (self.evidence/('dump-'+label+'.json')).write_text(json.dumps({'sha256':hashlib.sha256(dump).hexdigest(),'bytes':len(dump),'catalog_equal':True,'rows_equal':True,'restored_versions':count}))
    def execute(self):
        self.preflight();self.start('a');self.versions('a',26)
        self.sql('a','seed_base.sql','seed-base');self.native('a','bootstrap')
        self.sql('a','seed_orders.sql','seed-orders');self.sql('a','seed_variants.sql','seed-variants');self.sql('a','snapshot.sql','snapshot-baseline')
        self.restore('baseline',26)
        for f in (HERE/'additions').glob('*.sql'):shutil.copyfile(f,self.stacks['a']['dir']/'supabase/migrations'/f.name)
        self.command(['supabase','migration','up','--local'],'upgrade',self.stacks['a']['dir'],timeout=240);self.versions('a',46)
        state=json.loads((self.work/'auth-a.json').read_text())
        test=(HERE/'post_upgrade.test.sql').read_text().replace('PLACEHOLDER_OWNER_SESSION',state['owner_session']).replace('PLACEHOLDER_FOREIGN_SESSION',state['foreign_session'])
        tap_ok(self.query('a',test,'post-upgrade-tap').decode());tap_ok(self.sql('a','rights.test.sql','rights-tap').decode())
        before=self.query('a',"select jsonb_build_object('orders',(select count(*) from public.orders),'payments',(select count(*) from public.order_payments),'outbox',(select count(*) from public.outbox_events))",'noop-before')
        self.command(['supabase','migration','up','--local'],'upgrade-noop',self.stacks['a']['dir'])
        after=self.query('a',"select jsonb_build_object('orders',(select count(*) from public.orders),'payments',(select count(*) from public.order_payments),'outbox',(select count(*) from public.outbox_events))",'noop-after')
        require(before==after,'No-op changed product counts')
        self.native('a','upgraded')
        self.restore('upgraded',46)
        self.command(['supabase','db','advisors','--local','--type','security','--level','warn','--fail-on','error'],'advisors',self.stacks['a']['dir'])
        # Raw advisor warnings still require review; keep status partial, never automatic merge gate PASS.
        return {'status':'NATIVE_CASES_COMPLETED_REVIEW_REQUIRED','mg03_closed':False,'run_id':self.run_id}
    def cleanup(self):
        failures=[]
        def attempt(label,fn):
            try:return fn()
            except Exception as e:failures.append(label+': '+type(e).__name__+': '+str(e));return None
        for k in sorted(self.started):
            project=self.stacks[k]['id']
            attempt('stop-'+k,lambda k=k:self.stop(k))
            ids=attempt('list-containers-'+k,lambda project=project:self.command(['docker','ps','-aq','--filter','label=com.supabase.cli.project='+project],'cleanup-containers-'+k))
            if ids and ids.strip():attempt('remove-containers-'+k,lambda ids=ids:self.command(['docker','rm','-f',*ids.decode().split()],'cleanup-rm-'+k))
            vols=attempt('list-volumes-'+k,lambda project=project:self.command(['docker','volume','ls','-q','--filter','label=com.supabase.cli.project='+project],'cleanup-volumes-'+k))
            if vols and vols.strip():attempt('remove-volumes-'+k,lambda vols=vols:self.command(['docker','volume','rm',*vols.decode().split()],'cleanup-vol-rm-'+k))
            for resource,args in [('containers',['docker','ps','-aq']),('volumes',['docker','volume','ls','-q'])]:
                remaining=attempt('verify-'+resource+'-'+k,lambda args=args,project=project:self.command([*args,'--filter','label=com.supabase.cli.project='+project],'cleanup-final-'+resource+'-'+k))
                if remaining and remaining.strip():failures.append('Own residual '+resource+': '+k)
        if self.network_created:attempt('network',lambda:self.command(['docker','network','rm',self.network],'cleanup-network'))
        # Local secret cleanup still runs after ANY provider/process/resource error.
        for k in sorted(self.stacks):
            d=self.stacks[k]['dir']
            def remove_directory(d=d):
                require(d.parent==self.work and d.name in ('a','b') and not d.is_symlink(),'Cleanup path outside own workspace')
                if d.exists():shutil.rmtree(d)
            attempt('directory-'+k,remove_directory)
        for p in sorted([*self.work.glob('*.json'),*self.work.glob('*.dump')]):
            attempt('private-file-'+p.name,lambda p=p:p.unlink(missing_ok=True))
        summary={'status':'FAIL' if failures else 'PASS','failures':failures}
        (self.evidence/'cleanup.json').write_text(json.dumps(summary))
        require(not failures,'Cleanup incomplete; see cleanup.json')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');parser.add_argument('--repo',type=Path);parser.add_argument('--tls-dir',type=Path)
    args=parser.parse_args();integrity()
    if not args.execute:
        print('PASS: package integrity only. Native cases NOT_RUN. MG02/MG03 remain open.');return
    require(args.repo and args.tls_dir,'Execution requires isolated pinned checkout and pretrusted disposable TLS directory')
    runner=Runner(args.repo,args.tls_dir);result={'status':'FAIL','mg03_closed':False,'run_id':runner.run_id}
    try:result=runner.execute()
    finally:
        try:runner.cleanup()
        except Exception:
            result['status']='FAIL_CLEANUP';raise
        finally:(runner.evidence/'result.json').write_text(json.dumps(result,indent=2));print('Evidence:',runner.evidence)

if __name__=='__main__':main()
