"""Offline negative tests for integrity/TAP/result gates. Does not invoke native probes."""
import copy,json,shutil,tempfile,unittest,subprocess
from pathlib import Path
from unittest.mock import patch
import harness

class Guards(unittest.TestCase):
    def test_valid_tap(self):self.assertEqual(harness.tap_ok('ok 1 - one\nok 2 - two\n1..2\n'),2)
    def test_failure_tap(self):
        for text in ['not ok 1 - bad\n1..1','Bail out! failure','ok 1\n1..2','ok 2\n1..1','ok 1 # SKIP\n1..1','ok 1 # TODO\n1..1','ok 1','1..0','ok 1\n1..1\n1..1','ok 1\nnot ok 2\n1..2']:
            with self.subTest(text=text),self.assertRaises(ValueError):harness.tap_ok(text)
    def test_bound_case_results(self):harness.check_results({'run_id':'r','stage':'s','status':'PASS','cleanup':{'status':'PASS'},'head':harness.HEAD,'forbidden_requests':0,'native_database_host':'127.0.0.1','cases':[{'id':'c','status':'PASS'}]},['c'],'r','s')
    def test_missing_duplicate_failed_unbound_case(self):
        base={'run_id':'r','stage':'s','status':'PASS','cleanup':{'status':'PASS'},'head':harness.HEAD,'forbidden_requests':0,'native_database_host':'127.0.0.1','cases':[{'id':'c','status':'PASS'}]}
        variants=[{'cleanup':{'status':'FAIL'}},{'status':'FAIL'},{'head':'wrong'},{'forbidden_requests':1},{'native_database_host':'remote.invalid'},{'run_id':'wrong'},{'stage':'wrong'},{'cases':[]},{'cases':[{'id':'c','status':'NOT_RUN'}]},{'cases':[{'id':'c','status':'PASS'},{'id':'c','status':'PASS'}]},{'cases':[{'id':'unexpected','status':'PASS'}]}]
        for v in variants:
            with self.subTest(v=v),self.assertRaises(ValueError):harness.check_results({**base,**v},['c'],'r','s')
    def test_package_integrity(self):self.assertEqual(harness.integrity()['head'],harness.HEAD)
    def test_tampered_payload_and_extra_file(self):
        with tempfile.TemporaryDirectory(prefix='mg03-offline-tamper-') as tmp:
            dst=Path(tmp)/'package';shutil.copytree(harness.HERE,dst,ignore=shutil.ignore_patterns('__pycache__'))
            (dst/'seed_orders.sql').write_text('-- corrupted\n')
            with self.assertRaises(ValueError):harness.integrity(dst)
            shutil.copyfile(harness.HERE/'seed_orders.sql',dst/'seed_orders.sql');(dst/'extra.txt').write_text('unexpected')
            with self.assertRaises(ValueError):harness.integrity(dst)
    def test_symlink_rejected(self):
        with tempfile.TemporaryDirectory(prefix='mg03-offline-link-') as tmp:
            dst=Path(tmp)/'package';shutil.copytree(harness.HERE,dst,ignore=shutil.ignore_patterns('__pycache__'))
            target=dst/'seed_orders.sql';target.unlink();target.symlink_to(harness.HERE/'seed_orders.sql')
            with self.assertRaises(ValueError):harness.integrity(dst)
    def test_default_never_constructs_runner_or_calls_tools(self):
        with patch('sys.argv',['run.py']),patch.object(harness,'Runner',side_effect=AssertionError('Native Runner reached')),patch.object(harness.subprocess,'run',side_effect=AssertionError('External process reached')):
            harness.main()
    def test_execute_without_scope_stops_before_tools(self):
        with patch('sys.argv',['run.py','--execute']),patch.object(harness,'Runner',side_effect=AssertionError('Runner before scope')):
            with self.assertRaises(ValueError):harness.main()
    def test_no_docker_preflight_stops_without_native_command(self):
        with tempfile.TemporaryDirectory() as tmp:
            runner=harness.Runner(Path(tmp),Path(tmp))
            try:
                with patch.object(harness.shutil,'which',return_value=None),patch.object(runner,'command',side_effect=AssertionError('Command after missing Docker')):
                    with self.assertRaises(ValueError):runner.preflight()
            finally:shutil.rmtree(runner.work)

    def test_command_receipt_preserves_native_result_and_repeated_commands(self):
        with tempfile.TemporaryDirectory() as tmp:
            runner=harness.Runner(Path(tmp),Path(tmp))
            try:
                proof=runner.evidence/'native-bootstrap.json'
                native={'status':'PASS','cleanup':{'status':'PASS'},'head':harness.HEAD,'run_id':runner.run_id,'stage':'bootstrap','forbidden_requests':0,'native_database_host':'127.0.0.1','cases':[{'id':'UP-01-AUTH-BASELINE','status':'PASS'}]}
                def fake(args,**kwargs):
                    proof.write_text(json.dumps(native))
                    return subprocess.CompletedProcess(args,0,b'completed',b'')
                with patch.object(harness.subprocess,'run',side_effect=fake):
                    runner.command(['node','native.mjs'],'native-bootstrap')
                    runner.command(['node','native.mjs'],'native-bootstrap')
                self.assertEqual(json.loads(proof.read_text()),native)
                self.assertEqual(len(list(runner.command_evidence.glob('*.json'))),2)
                harness.check_results(json.loads(proof.read_text()),['UP-01-AUTH-BASELINE'],runner.run_id,'bootstrap')
            finally:shutil.rmtree(runner.work)

    def test_failed_tap_command_retains_sanitized_diagnostics(self):
        with tempfile.TemporaryDirectory() as tmp:
            runner=harness.Runner(Path(tmp),Path(tmp))
            try:
                token='a'*24+'.'+'b'*24+'.'+'c'*24
                failed=subprocess.CompletedProcess(['psql'],1,b'not ok 1\n1..1',token.encode())
                with patch.object(harness.subprocess,'run',return_value=failed),self.assertRaises(ValueError):
                    runner.command(['psql'],'post-upgrade-tap')
                self.assertIn('not ok',next(runner.command_evidence.glob('*.stdout')).read_text())
                stderr=next(runner.command_evidence.glob('*.stderr')).read_text()
                self.assertNotIn(token,stderr);self.assertIn('[REDACTED_JWT]',stderr)
            finally:shutil.rmtree(runner.work)

    def test_cleanup_failure_does_not_skip_secrets_or_other_resources(self):
        with tempfile.TemporaryDirectory() as tmp:
            runner=harness.Runner(Path(tmp),Path(tmp))
            try:
                d=runner.work/'a';d.mkdir();(d/'config.toml').write_text('private fixture')
                runner.stacks['a']={'dir':d,'id':runner.run_id+'-a','container':'own-db'}
                runner.started.add('a');runner.network_created=True
                for n in ['context.json','auth-a.json','shared-signing-keys.json','baseline.dump']:(runner.work/n).write_text('synthetic private')
                calls=[]
                def fake(args,name,*a,**kw):
                    calls.append(args)
                    if 'ps' in args:raise RuntimeError('injected resource-list error')
                    return b''
                with patch.object(runner,'stop',side_effect=RuntimeError('injected stop error')),patch.object(runner,'command',side_effect=fake),self.assertRaises(ValueError):runner.cleanup()
                self.assertFalse(d.exists())
                self.assertFalse(list(runner.work.glob('*.json')));self.assertFalse(list(runner.work.glob('*.dump')))
                self.assertTrue(any(x[:3]==['docker','network','rm'] for x in calls))
                self.assertEqual(json.loads((runner.evidence/'cleanup.json').read_text())['status'],'FAIL')
            finally:shutil.rmtree(runner.work)

    def test_timeout_writes_separate_failed_receipt(self):
        with tempfile.TemporaryDirectory() as tmp:
            runner=harness.Runner(Path(tmp),Path(tmp))
            try:
                with patch.object(harness.subprocess,'run',side_effect=subprocess.TimeoutExpired(['node'],1)),self.assertRaises(ValueError):
                    runner.command(['node'],'native-bootstrap',timeout=1)
                receipt=json.loads(next(runner.command_evidence.glob('*.json')).read_text())
                self.assertEqual(receipt['status'],'TIMEOUT');self.assertIsNone(receipt['exit'])
                self.assertFalse((runner.evidence/'native-bootstrap.json').exists())
            finally:shutil.rmtree(runner.work)

    def test_only_checked_local_docker_endpoint(self):
        context={'Endpoints':{'docker':{'Host':'unix:///var/run/docker.sock'}}}
        self.assertEqual(harness.docker_socket(context,{}),'unix:///var/run/docker.sock')
        for env in [{'DOCKER_HOST':'tcp://remote.invalid:2375'},{'DOCKER_HOST':'ssh://remote.invalid'},{'DOCKER_CONTEXT':'production'}]:
            with self.subTest(env=env),self.assertRaises(ValueError):harness.docker_socket(context,env)
        with self.assertRaises(ValueError):harness.docker_socket({'Endpoints':{'docker':{'Host':'tcp://remote.invalid:2375'}}},{})

    def test_restore_keeps_initdb_public_schema(self):
        with tempfile.TemporaryDirectory() as tmp:
            runner=harness.Runner(Path(tmp),Path(tmp))
            try:
                for k in ['a','b']:
                    d=runner.work/k;d.mkdir();runner.stacks[k]={'dir':d,'id':'own-'+k,'container':'db-'+k}
                    (runner.evidence/('images-'+k+'.json')).write_text('[{"image":"same-digest"}]')
                commands=[];queries=[]
                def fake_command(args,name,*a,**kw):
                    commands.append(args)
                    if 'pg_dump' in args:return b'fake-dump'
                    if name=='b-services':return b'db-id\nservice-id\n'
                    if name=='b-db':return b'db-id\n'
                    return b''
                def fake_query(k,text,name):
                    queries.append(text)
                    return b'1\n' if name=='target-public-schema' else b't\n'
                with patch.object(runner,'versions'),patch.object(runner,'sql',return_value=b'catalog'),patch.object(runner,'command',side_effect=fake_command),patch.object(runner,'query',side_effect=fake_query),patch.object(runner,'start'),patch.object(runner,'stop'),patch.object(runner,'native'):
                    runner.restore('baseline',26)
                self.assertTrue(any("nspname='public'" in q for q in queries))
                self.assertFalse(any('drop schema' in q.lower() for q in queries))
                self.assertTrue(any('pg_restore' in a for a in commands))
            finally:shutil.rmtree(runner.work)

if __name__=='__main__':unittest.main(verbosity=2)
