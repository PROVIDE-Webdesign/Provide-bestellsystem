-- Main-schema-only extension, committed BEFORE the 20 additions. No provider calls.
begin;
insert into public.locations(id,restaurant_id,slug,display_name,status,timezone,address_line_1,postal_code,city,country_code)
values('e3000000-0000-0000-0000-000000000003','e2000000-0000-0000-0000-000000000001','upgrade-a-west','Teststandort West','active','Europe/Berlin','Testweg 3','52062','Aachen','DE');
insert into public.restaurant_feature_flags(restaurant_id,feature_key,enabled)
values('e2000000-0000-0000-0000-000000000001','fulfillment.delivery',true);
insert into public.availability_schedule_versions
(id,restaurant_id,location_id,version_number,minimum_lead_minutes,maximum_advance_days,slot_interval_minutes,default_order_capacity,default_item_capacity,created_by_user_id)
values('eb800000-0000-0000-0000-000000000001','e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001',2,15,14,15,10,100,'e1000000-0000-0000-0000-000000000001');
insert into public.availability_windows(restaurant_id,location_id,schedule_version_id,fulfillment_type,weekday,opens_at,closes_at)
select 'e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001','eb800000-0000-0000-0000-000000000001',kind,weekday,'00:00:00'::time,'23:59:59'::time
from generate_series(0,6) weekday cross join (values('pickup'),('delivery')) kinds(kind);
update public.availability_schedule_versions set status='published',published_at=now(),published_by_user_id='e1000000-0000-0000-0000-000000000001' where id='eb800000-0000-0000-0000-000000000001';
insert into public.availability_publications(restaurant_id,location_id,schedule_version_id,effective_at,actor_user_id,authentication_assurance)
values('e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001','eb800000-0000-0000-0000-000000000001',statement_timestamp(),'e1000000-0000-0000-0000-000000000001','aal2');
do $$ declare policy uuid; oid uuid; target_time timestamptz; quote jsonb; reply jsonb; i integer;
begin
 policy:=private.create_delivery_policy('e1000000-0000-0000-0000-000000000001','aal2','e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001','[{"postalCodes":["52062"],"minimumAmountMinor":1000,"feeAmountMinor":350}]');
 perform private.publish_delivery_policy('e1000000-0000-0000-0000-000000000001','aal2','e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001',policy);
 target_time:=date_trunc('day',now())+interval '1 day 12 hours';
 quote:=private.quote_public_delivery_order('upgrade-restaurant-a','upgrade-a-mitte','e4000000-0000-0000-0000-000000000001','e5000000-0000-0000-0000-000000000001',target_time,'[{"menu_item_id":"e6000000-0000-0000-0000-000000000001","quantity":1}]','52062');
 reply:=private.submit_public_guest_delivery_order('upgrade-restaurant-a','upgrade-a-mitte','e4000000-0000-0000-0000-000000000001','e5000000-0000-0000-0000-000000000001',target_time,'[{"menu_item_id":"e6000000-0000-0000-0000-000000000001","quantity":1}]','premerge-legacy-order-0005','{"contact_name":"Synthetic Delivery Guest","phone_e164":"+15555550102","email":"delivery@example.invalid"}','{"address_line_1":"Testweg 9","postal_code":"52062","city":"Aachen","country_code":"DE"}',quote,'upgrade-v1',30);
 oid:=(reply->>'orderId')::uuid;
 insert into upgrade_evidence.orders values(5,oid,target_time);
 for i in 3..4 loop
  select id into oid from upgrade_evidence.orders where n=i;
  perform private.create_payment_attempt('e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001',oid,'upgrade-attempt-000'||i,'synthetic','upgrade-reference-000'||i);
  perform private.apply_verified_payment_event('e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001',oid,'synthetic','upgrade-reference-000'||i,'upgrade-capture-000'||i,'payment_intent.succeeded','captured',1250,'EUR',repeat('a',64),now());
  if i=4 then
   perform private.apply_verified_payment_event('e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001',oid,'synthetic','upgrade-reference-0004','upgrade-refund-0004','refund.updated','refunded',1250,'EUR',repeat('b',64),now());
  end if;
 end loop;
end $$;
commit;
