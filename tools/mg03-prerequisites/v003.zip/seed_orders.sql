begin;
-- Prepared synthetic upgrade fixture, NOT EXECUTED. Disposable local database only.
-- No provider calls. Table rows use .invalid contacts and database-only payment obligations.
insert into public.restaurant_feature_flags(restaurant_id,feature_key,enabled)
values ('e2000000-0000-0000-0000-000000000001','payment.online',true);

create schema upgrade_evidence;
create table upgrade_evidence.orders (n integer primary key, id uuid not null, requested_for timestamptz not null);
do $$ declare i integer; oid uuid; requested timestamptz;
begin
 for i in 1..4 loop
  requested:=date_trunc('day',now())+interval '1 day 10 hours'+i*interval '15 minutes';
  oid:=private.submit_order_with_payment(
   'e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001',
   'e4000000-0000-0000-0000-000000000001','e5000000-0000-0000-0000-000000000001',
   'pickup',requested,'[{"menu_item_id":"e6000000-0000-0000-0000-000000000001","quantity":1}]',
   'premerge-legacy-order-000'||i,now(),case when i=2 then 'on_fulfillment' else 'online' end);
  insert into upgrade_evidence.orders values(i,oid,requested);
  insert into public.order_customer_contacts
   (restaurant_id,location_id,order_id,contact_name,phone_e164,email,privacy_notice_version,retention_until)
  values('e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001',oid,
   'Synthetic Upgrade Guest','+15555550101','upgrade-'||i||'@example.invalid','upgrade-v1',now()+interval '30 days');
 end loop;
end $$;

commit;
