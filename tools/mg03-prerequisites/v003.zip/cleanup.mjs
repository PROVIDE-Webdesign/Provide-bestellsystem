/** Best-effort close of EVERY owned native resource; never conceal any failure. */
export async function closeOwnedResources(actions) {
  const failures=[];
  for(const [name,close] of actions) {
    try { await close(); }
    catch(error) { failures.push({resource:name,error_class:error?.constructor?.name||'Error'}); }
  }
  return {status:failures.length?'FAIL':'PASS',failures};
}
