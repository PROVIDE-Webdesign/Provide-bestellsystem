// Pure local control-flow tests: no browser, API, DB, Docker or provider.
import assert from 'node:assert/strict';
import {closeOwnedResources} from './cleanup.mjs';
let calls=[];
const ok=await closeOwnedResources([['browser',async()=>calls.push('browser')],['sql',async()=>calls.push('sql')]]);
assert.deepEqual(calls,['browser','sql']);assert.equal(ok.status,'PASS');
calls=[];
const failed=await closeOwnedResources([['browser',async()=>{calls.push('browser');throw Error('synthetic secret must not appear');}],['sql',async()=>calls.push('sql')]]);
assert.deepEqual(calls,['browser','sql']);assert.equal(failed.status,'FAIL');assert.equal(failed.failures[0].error_class,'Error');assert.ok(!JSON.stringify(failed).includes('synthetic secret'));
const multiple=await closeOwnedResources([['first',async()=>{throw TypeError();}],['last',async()=>{throw RangeError();}]]);
assert.equal(multiple.failures.length,2);assert.equal(multiple.status,'FAIL');
console.log('PASS: 3 native-cleanup control-flow scenarios, no native resources started');
