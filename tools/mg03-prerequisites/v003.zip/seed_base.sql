begin;
-- Synthetic fixture, for disposable local/CI databases only. No automatic seeding or deployment.
insert into auth.users (id, email) values ('e1000000-0000-0000-0000-000000000001',
'storefront-owner-a@example.invalid'), ('e1000000-0000-0000-0000-000000000002',
'storefront-manager-a@example.invalid'), ('e1000000-0000-0000-0000-000000000003',
'storefront-kitchen-a@example.invalid'), ('e1000000-0000-0000-0000-000000000004',
'storefront-driver-a@example.invalid'), ('e1000000-0000-0000-0000-000000000005',
'storefront-owner-b@example.invalid'), ('e1000000-0000-0000-0000-000000000006',
'storefront-manager-unassigned@example.invalid'); insert into public.restaurants (id, slug,
display_name, status) values ( 'e2000000-0000-0000-0000-000000000001', 'upgrade-restaurant-a',
'PROVIDE Testküche', 'active' ), ( 'e2000000-0000-0000-0000-000000000002',
'upgrade-restaurant-b', 'Andere Testküche', 'active' ); insert into public.restaurant_memberships
(restaurant_id, user_id, role, status) values ( 'e2000000-0000-0000-0000-000000000001',
'e1000000-0000-0000-0000-000000000001', 'owner', 'active' ), (
'e2000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000002', 'manager', 'active'
), ( 'e2000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000003', 'kitchen',
'active' ), ( 'e2000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000004',
'driver', 'active' ), ( 'e2000000-0000-0000-0000-000000000002',
'e1000000-0000-0000-0000-000000000005', 'owner', 'active' ), (
'e2000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000006', 'manager', 'active'
); insert into public.locations ( id, restaurant_id, slug, display_name, status, timezone,
address_line_1, postal_code, city, country_code ) values ( 'e3000000-0000-0000-0000-000000000001',
'e2000000-0000-0000-0000-000000000001', 'upgrade-a-mitte', 'Teststandort Mitte', 'active',
'Europe/Berlin', 'Testweg 1', '52062', 'Aachen', 'DE' ), ( 'e3000000-0000-0000-0000-000000000002',
'e2000000-0000-0000-0000-000000000002', 'upgrade-b-mitte', 'Anderer Teststandort', 'active',
'Europe/Berlin', 'Testweg 2', '50667', 'Koeln', 'DE' ); insert into
public.restaurant_membership_locations (restaurant_id, user_id, location_id) values (
'e2000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000002',
'e3000000-0000-0000-0000-000000000001' ), ( 'e2000000-0000-0000-0000-000000000001',
'e1000000-0000-0000-0000-000000000003', 'e3000000-0000-0000-0000-000000000001' ), (
'e2000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000004',
'e3000000-0000-0000-0000-000000000001' ); update public.onboarding_check_results as result set
status = 'passed', checked_by_user_id = case when result.restaurant_id =
'e2000000-0000-0000-0000-000000000001' then 'e1000000-0000-0000-0000-000000000001'::uuid else
'e1000000-0000-0000-0000-000000000005'::uuid end, checked_at = now() where result.restaurant_id in (
'e2000000-0000-0000-0000-000000000001', 'e2000000-0000-0000-0000-000000000002' ); update
public.restaurant_activation_states as activation set onboarding_status = 'approved', go_live_status
= 'live', approved_by_user_id = case when activation.restaurant_id =
'e2000000-0000-0000-0000-000000000001' then 'e1000000-0000-0000-0000-000000000001'::uuid else
'e1000000-0000-0000-0000-000000000005'::uuid end, approved_at = now(), went_live_at = now() where
activation.restaurant_id in ( 'e2000000-0000-0000-0000-000000000001',
'e2000000-0000-0000-0000-000000000002' ); update public.location_activation_states as activation set
onboarding_status = 'approved', go_live_status = 'live', approved_by_user_id = case when
activation.restaurant_id = 'e2000000-0000-0000-0000-000000000001' then
'e1000000-0000-0000-0000-000000000001'::uuid else 'e1000000-0000-0000-0000-000000000005'::uuid end,
approved_at = now(), went_live_at = now() where activation.restaurant_id in (
'e2000000-0000-0000-0000-000000000001', 'e2000000-0000-0000-0000-000000000002' ); insert into
public.restaurant_feature_flags (restaurant_id, feature_key, enabled) values
('e2000000-0000-0000-0000-000000000001', 'ordering.accept_orders', true),
('e2000000-0000-0000-0000-000000000001', 'fulfillment.pickup', true),
('e2000000-0000-0000-0000-000000000001', 'catalog.public_menu', true); insert into public.menus (id,
restaurant_id, slug, display_name) values ( 'e4000000-0000-0000-0000-000000000001',
'e2000000-0000-0000-0000-000000000001', 'upgrade-test-menu', 'Unsere Speisekarte' ); insert into
public.menu_versions ( id, restaurant_id, menu_id, version_number, currency_code, created_by_user_id
) values ( 'e5000000-0000-0000-0000-000000000001', 'e2000000-0000-0000-0000-000000000001',
'e4000000-0000-0000-0000-000000000001', 1, 'EUR', 'e1000000-0000-0000-0000-000000000001' ); insert
into public.menu_items (id, restaurant_id, menu_id, slug) values (
'e6000000-0000-0000-0000-000000000001', 'e2000000-0000-0000-0000-000000000001',
'e4000000-0000-0000-0000-000000000001', 'curry' ), ( 'e6000000-0000-0000-0000-000000000002',
'e2000000-0000-0000-0000-000000000001', 'e4000000-0000-0000-0000-000000000001', 'reis' ); insert
into public.menu_version_sections ( restaurant_id, menu_id, menu_version_id, section_key,
display_name ) values ( 'e2000000-0000-0000-0000-000000000001',
'e4000000-0000-0000-0000-000000000001', 'e5000000-0000-0000-0000-000000000001', 'gerichte',
'Gerichte' ); insert into public.menu_version_items ( restaurant_id, menu_id, menu_version_id,
menu_item_id, section_key, display_name, price_amount_minor, sort_order ) values (
'e2000000-0000-0000-0000-000000000001', 'e4000000-0000-0000-0000-000000000001',
'e5000000-0000-0000-0000-000000000001', 'e6000000-0000-0000-0000-000000000001', 'gerichte',
'Gemüsecurry', 1250, 1 ), ( 'e2000000-0000-0000-0000-000000000001',
'e4000000-0000-0000-0000-000000000001', 'e5000000-0000-0000-0000-000000000001',
'e6000000-0000-0000-0000-000000000002', 'gerichte', 'Duftreis', 300, 2 ); insert into
public.menu_items (id, restaurant_id, menu_id, slug) values
('e6000000-0000-0000-0000-000000000003','e2000000-0000-0000-0000-000000000001','e4000000-0000-0000-0000-000000000001','hidden-item');
insert into public.menu_version_items
(restaurant_id,menu_id,menu_version_id,menu_item_id,section_key,display_name,price_amount_minor,is_active)
values
('e2000000-0000-0000-0000-000000000001','e4000000-0000-0000-0000-000000000001','e5000000-0000-0000-0000-000000000001','e6000000-0000-0000-0000-000000000003','gerichte','Hidden
inactive dish',500,false); update public.menu_versions set status = 'published',
published_by_user_id = 'e1000000-0000-0000-0000-000000000001', published_at = now() where id =
'e5000000-0000-0000-0000-000000000001'; insert into public.menu_publications ( id, restaurant_id,
location_id, menu_id, menu_version_id, publication_kind, effective_at, actor_user_id,
authentication_assurance ) values ( 'e7000000-0000-0000-0000-000000000001',
'e2000000-0000-0000-0000-000000000001', 'e3000000-0000-0000-0000-000000000001',
'e4000000-0000-0000-0000-000000000001', 'e5000000-0000-0000-0000-000000000001', 'publish', now(),
'e1000000-0000-0000-0000-000000000001', 'aal2' ); insert into public.availability_schedule_versions
( id, restaurant_id, location_id, version_number, minimum_lead_minutes, maximum_advance_days,
slot_interval_minutes, default_order_capacity, default_item_capacity, created_by_user_id ) values (
'e8000000-0000-0000-0000-000000000001', 'e2000000-0000-0000-0000-000000000001',
'e3000000-0000-0000-0000-000000000001', 1, 15, 14, 15, 10, 100,
'e1000000-0000-0000-0000-000000000001' ); insert into public.availability_windows ( restaurant_id,
location_id, schedule_version_id, fulfillment_type, weekday, opens_at, closes_at ) select
'e2000000-0000-0000-0000-000000000001', 'e3000000-0000-0000-0000-000000000001',
'e8000000-0000-0000-0000-000000000001', 'pickup', weekday, '00:00:00'::time, '23:59:59'::time from
generate_series(0, 6) as weekday; update public.availability_schedule_versions set status =
'published', published_by_user_id = 'e1000000-0000-0000-0000-000000000001', published_at = now()
where id = 'e8000000-0000-0000-0000-000000000001'; insert into public.availability_publications (
id, restaurant_id, location_id, schedule_version_id, effective_at, actor_user_id,
authentication_assurance ) values ( 'e9000000-0000-0000-0000-000000000001',
'e2000000-0000-0000-0000-000000000001', 'e3000000-0000-0000-0000-000000000001',
'e8000000-0000-0000-0000-000000000001', now(), 'e1000000-0000-0000-0000-000000000001', 'aal2' );
commit;
