-- Every old populated public/private table is captured with its old primary key and columns.
-- Added columns/rows are permitted; losing or silently changing an old row is not.
create table upgrade_evidence.baseline
 (schema_name text, table_name text, columns_before text[], pk text[], rows_before jsonb,
 primary key(schema_name,table_name));
do $$ declare t record; cols text[]; keys text[]; data jsonb;
begin
 for t in select c.oid,n.nspname,c.relname from pg_class c join pg_namespace n on n.oid=c.relnamespace
  where c.relkind='r' and n.nspname in ('public','private','auth','supabase_migrations') order by n.nspname,c.relname loop
  select array_agg(a.attname order by a.attnum) into cols from pg_attribute a
   where a.attrelid=t.oid and a.attnum>0 and not a.attisdropped;
  select array_agg(a.attname order by k.ord) into keys from pg_index i
   cross join lateral unnest(i.indkey) with ordinality k(num,ord)
   join pg_attribute a on a.attrelid=i.indrelid and a.attnum=k.num
   where i.indrelid=t.oid and i.indisprimary;
  execute format('select coalesce(jsonb_agg(to_jsonb(x)),''[]''::jsonb) from %I.%I x',t.nspname,t.relname) into data;
  if jsonb_array_length(data)>0 then
   if keys is null then raise exception 'populated legacy table has no supported PK: %.%',t.nspname,t.relname;end if;
   insert into upgrade_evidence.baseline values(t.nspname,t.relname,cols,keys,data);
  end if;
 end loop;
end $$;
create function upgrade_evidence.legacy_rows_match(s text,t text,cols text[],keys text[],expected jsonb)
returns boolean language plpgsql as $$
declare row_before jsonb; found_row jsonb; predicate text; c text;
begin
 for row_before in select value from jsonb_array_elements(expected) loop
  select string_agg(format('to_jsonb(x)->%L = $1->%L',key,key),' and ') into predicate from unnest(keys) key;
  execute format('select to_jsonb(x) from %I.%I x where %s',s,t,predicate) into found_row using row_before;
  if found_row is null then return false;end if;
  foreach c in array cols loop
   if found_row->c is distinct from row_before->c then return false;end if;
  end loop;
 end loop;
 return true;
end $$;
