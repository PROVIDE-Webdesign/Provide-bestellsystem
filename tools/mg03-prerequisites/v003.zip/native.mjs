/** Prepared native probes. Only the separately authorized runner invokes this file.
 * Real local Auth/MFA/PG/production Worker/Realtime/HTTPS and production MenuEditor.
 * Gateway transport/challenge/provider are explicit local doubles, never real Edge evidence.
 */
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFile,writeFile,mkdir } from 'node:fs/promises';
import { join,resolve } from 'node:path';
import { createHmac,randomUUID } from 'node:crypto';
import { createServer } from 'node:https';
import { Readable } from 'node:stream';
import { closeOwnedResources } from './cleanup.mjs';

const c=JSON.parse(await readFile(process.argv[2],'utf8'));
assert.match(c.run_id,/^provide-mg03-[A-Za-z0-9_-]+$/);
for(const url of [c.database,c.url])assert.equal(new URL(url).hostname,'127.0.0.1');
assert.ok(c.stage==='bootstrap'||['upgraded','restore-baseline','restore-upgraded'].includes(c.stage));
const root=resolve(c.repo),own=resolve(c.work);
assert.ok(resolve(c.state).startsWith(own+'/'));
assert.ok(resolve(c.output).startsWith(own+'/evidence/'));
const dashboardRequire=createRequire(join(root,'apps/dashboard/package.json'));
const apiRequire=createRequire(join(root,'apps/api/package.json'));
const frontRequire=createRequire(join(root,'apps/storefront/package.json'));
const {createClient}=dashboardRequire('@supabase/supabase-js');
const {Client}=apiRequire('pg');
const rawFetch=globalThis.fetch;
let forbiddenRequests=0;
globalThis.fetch=(url,init)=>{
 const u=new URL(typeof url==='string'||url instanceof URL?url:url.url);
 if(u.hostname!=='127.0.0.1'){forbiddenRequests++;throw Error('External request denied');}
 return rawFetch(url,{...init,redirect:'error'});
};
const sql=new Client({connectionString:c.database,connectionTimeoutMillis:5000,query_timeout:10000});
const admin=createClient(c.url,c.admin,{auth:{persistSession:false,autoRefreshToken:false}});
const ids=n=>`e1000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const restaurant='e2000000-0000-0000-0000-000000000001';
const location='e3000000-0000-0000-0000-000000000001';
const foreign='e2000000-0000-0000-0000-000000000002';
const otherSite='e3000000-0000-0000-0000-000000000003';
const menu='e4000000-0000-0000-0000-000000000001';
const version='e5000000-0000-0000-0000-000000000001';
const report={run_id:c.run_id,stage:c.stage,head:'cbc78a2240eba05840b6cd712c89025bb6377635',cases:[],status:'RUNNING',native_database_host:'127.0.0.1',provider:'synthetic only',forbidden_requests:0};
let state={},vite,https,browser;
const clients=[];
async function caseRun(id,fn){
 try{await fn();report.cases.push({id,status:'PASS'});}
 catch(e){report.cases.push({id,status:'FAIL',error_class:e?.constructor?.name||'Error'});throw Error('Native case failed: '+id);}
}
function totp(secret){
 let bits='';for(const x of secret.replace(/=/g,'').toUpperCase()){const n='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'.indexOf(x);assert.ok(n>=0);bits+=n.toString(2).padStart(5,'0');}
 const key=Buffer.from((bits.match(/.{8}/g)||[]).map(x=>parseInt(x,2)));const counter=Buffer.alloc(8);counter.writeBigUInt64BE(BigInt(Math.floor(Date.now()/30000)));
 const h=createHmac('sha1',key).update(counter).digest();const offset=h.at(-1)&15;
 return String((h.readUInt32BE(offset)&0x7fffffff)%1000000).padStart(6,'0');
}
const decode=token=>JSON.parse(Buffer.from(token.split('.')[1],'base64url'));
async function login(n,mfa=true){
 const user=state.users[String(n)];assert.ok(user);
 const client=createClient(c.url,c.anon,{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});clients.push(client);
 const signed=await client.auth.signInWithPassword({email:user.email,password:user.password});assert.equal(signed.error,null);
 const aal1=signed.data.session.access_token;
 if(mfa){
  let factorId=user.factor,secret=user.secret;
  if(!factorId){const enrolled=await client.auth.mfa.enroll({factorType:'totp',friendlyName:'Isolated MG03'});assert.equal(enrolled.error,null);factorId=enrolled.data.id;secret=enrolled.data.totp.secret;user.factor=factorId;user.secret=secret;}
  const challenge=await client.auth.mfa.challenge({factorId});assert.equal(challenge.error,null);
  let verified=await client.auth.mfa.verify({factorId,challengeId:challenge.data.id,code:totp(secret)});
  if(verified.error){
   // Real provider may reject same counter on a second login. One bounded new window, no MFA bypass.
   await new Promise(r=>setTimeout(r,31000-Date.now()%30000));
   const retry=await client.auth.mfa.challenge({factorId});assert.equal(retry.error,null);
   verified=await client.auth.mfa.verify({factorId,challengeId:retry.data.id,code:totp(secret)});
  }
  assert.equal(verified.error,null);
 }
 const session=(await client.auth.getSession()).data.session;assert.ok(session);
 const claims=decode(session.access_token);assert.equal(claims.sub,user.id);assert.equal(claims.aal,mfa?'aal2':'aal1');assert.ok(claims.session_id);
 if(mfa){const live=await sql.query('select s.aal,s.factor_id,f.status from auth.sessions s left join auth.mfa_factors f on f.id=s.factor_id where s.id=$1 and s.user_id=$2',[claims.session_id,user.id]);assert.equal(live.rows[0]?.aal,'aal2');assert.equal(live.rows[0]?.status,'verified');}
 user.token=session.access_token;user.session=claims.session_id;
 return {client,token:session.access_token,aal1,user};
}
async function saveState(){await writeFile(c.state,JSON.stringify(state),{mode:0o600});}
async function bootstrap(){
 state={users:{}};
 await caseRun('UP-01-AUTH-BASELINE',async()=>{
  for(let n=1;n<=6;n++){
   const id=ids(n);const email=(await sql.query('select email from auth.users where id=$1',[id])).rows[0].email;
   const password='Synthetic-'+randomUUID()+'!';
   // Baseline user rows are synthetic fixtures; native credential update/login/MFA remains real Auth.
   await sql.query("update auth.users set aud='authenticated',role='authenticated',email_confirmed_at=now() where id=$1",[id]);
   const update=await admin.auth.admin.updateUserById(id,{password,email_confirm:true});assert.equal(update.error,null);
   state.users[String(n)]={id,email,password};await login(n,true);
  }
  state.owner_session=state.users['1'].session;state.foreign_session=state.users['5'].session;
  await saveState();
 });
}
async function restored(){
 state=JSON.parse(await readFile(join(own,'auth-a.json'),'utf8'));
 await caseRun('UP-04-RESTORE-AUTH',async()=>{const auth=await login(1,true);assert.equal((await auth.client.auth.getUser()).error,null);await saveState();});
 await caseRun('UP-04-RESTORE-REST',async()=>{
  const u=state.users['1'];const response=await fetch(c.url+'/rest/v1/orders?select=id',{headers:{apikey:c.anon,authorization:'Bearer '+u.token}});assert.equal(response.status,200);const rows=await response.json();const legacy=(await sql.query('select id from upgrade_evidence.orders')).rows;assert.ok(legacy.every(x=>rows.some(y=>y.id===x.id)));
 });
 if(c.stage==='restore-upgraded')await caseRun('UP-04-RESTORE-REALTIME',async()=>{await realtimeProbe(state.users['1'].token,true);});
}
async function realtimeProbe(token,allow,topic='orders:v1:'+restaurant+':'+location){
 // Realtime must use HTTPS/WSS proxy on upgraded probe; restore transport bound explicitly to local stack.
 const url=c.stage==='upgraded'?'https://127.0.0.1:4319':c.url;
 const client=createClient(url,c.anon,{accessToken:()=>Promise.resolve(token),auth:{persistSession:false,autoRefreshToken:false}});clients.push(client);await client.realtime.setAuth(token);
 const events=[];const channel=client.channel(topic,{config:{private:true,broadcast:{ack:true}}});
 channel.on('broadcast',{event:'orders.invalidated.v1'},x=>events.push(x.payload));
 try{
  const outcome=await new Promise((ok,no)=>{const timer=setTimeout(()=>no(Error('Realtime join timeout')),12000);channel.subscribe(s=>{if(s==='SUBSCRIBED'){clearTimeout(timer);ok('joined');}else if(s==='CHANNEL_ERROR'){clearTimeout(timer);ok('denied');}});});
  assert.equal(outcome,allow?'joined':'denied');
  if(allow){
   await sql.query('select private.invalidate_dashboard_orders($1,$2)',[restaurant,location]);
   const end=Date.now()+10000;while(!events.length&&Date.now()<end)await new Promise(r=>setTimeout(r,100));
   assert.ok(events.length);assert.deepEqual(Object.keys(events[0]).sort(),['id','schemaVersion']);
   assert.notEqual(await channel.send({type:'broadcast',event:'orders.invalidated.v1',payload:{schemaVersion:1,id:randomUUID()}}),'ok');
  }
 }finally{await client.removeChannel(channel);}
}
async function upgraded(){
 state=JSON.parse(await readFile(c.state,'utf8'));
 const auth=await login(1,true),manager=await login(2,true),kitchen=await login(3,true),foreignAuth=await login(5,true);
 await caseRun('UP-05-AAL1',async()=>{assert.equal((await sql.query('select private.account_session_live($1,$2,$3) allowed',[auth.user.id,decode(auth.aal1).session_id,'aal1'])).rows[0].allowed,false);});
 const newUser=await admin.auth.admin.createUser({email:'mg03-viewer-'+randomUUID()+'@example.invalid',password:'Synthetic-'+randomUUID()+'!',email_confirm:true});assert.equal(newUser.error,null);
 const viewerPassword='Synthetic-'+randomUUID()+'!';assert.equal((await admin.auth.admin.updateUserById(newUser.data.user.id,{password:viewerPassword})).error,null);
 state.users['viewer']={id:newUser.data.user.id,email:newUser.data.user.email,password:viewerPassword};
 await sql.query("insert into public.restaurant_memberships(restaurant_id,user_id,role,status) values($1,$2,'viewer','active')",[restaurant,newUser.data.user.id]);
 await sql.query('insert into public.restaurant_membership_locations(restaurant_id,user_id,location_id) values($1,$2,$3)',[restaurant,newUser.data.user.id,location]);
 const viewer=await login('viewer',false);
 const {createServer:createVite}=await import(frontRequire.resolve('vite'));
 const {default:react}=await import(frontRequire.resolve('@vitejs/plugin-react'));
 const ui=join(own,'ui');await mkdir(ui,{recursive:true});
 await writeFile(join(ui,'index.html'),'<div id="root"></div><script type="module" src="/entry.jsx"></script>');
 await writeFile(join(ui,'entry.jsx'),`import React from 'react';import{createRoot}from'react-dom/client';import{MenuEditor}from'/@fs/${root}/apps/dashboard/app/components/MenuEditor.tsx';createRoot(document.getElementById('root')).render(<MenuEditor restaurantId="${restaurant}" locations={[{id:"${location}",displayName:"Synthetic Mitte"}]}/>);`);
 const tls={key:await readFile(join(c.tls,'key.pem')),cert:await readFile(join(c.tls,'cert.pem'))};
 https=createServer(tls);
 vite=await createVite({configFile:false,root:ui,plugins:[react()],resolve:{alias:{'@':join(root,'apps/dashboard'),react:join(root,'apps/storefront/node_modules/react'),'react-dom':join(root,'apps/storefront/node_modules/react-dom')}},server:{middlewareMode:true,hmr:false,ws:{server:https,protocol:'wss',host:'127.0.0.1'},fs:{allow:[root,own]},proxy:{'/auth':{target:c.url,changeOrigin:false},'/rest':{target:c.url,changeOrigin:false},'/realtime':{target:c.url,changeOrigin:false,ws:true}}}});
 const {createProtectedIntegrationWorker}=await vite.ssrLoadModule(join(root,'apps/api/src/checkout-integration-fixture.ts'));
 const args=[];const noProvider=()=>{forbiddenRequests++;throw Error('External provider forbidden');};
 args[12]={session:noProvider,expire:noProvider,refund:noProvider};args[9]={send:noProvider};args[14]={send:noProvider};args[22]={invite:noProvider};
 // Production asymmetric verifier remains unchanged. Real Auth tokens must validate through JWKS.
 const worker=createProtectedIntegrationWorker(...args);
 const env={APP_ENV:'test',HYPERDRIVE:{connectionString:c.database},HYPERDRIVE_CACHE_DISABLED:'true',DASHBOARD_AUTH_ENABLED:'true',DASHBOARD_ORDER_OPERATIONS_ENABLED:'true',DASHBOARD_MENU_ENABLED:'true',SUPABASE_AUTH_ISSUER:c.url+'/auth/v1',SUPABASE_AUTH_AUDIENCE:'authenticated',CHECKOUT_WRITE_ENABLED:'true',CHECKOUT_PRIVACY_NOTICE_VERSION:'upgrade-v1',CHECKOUT_RETENTION_DAYS:'30',ORDER_STATUS_TOKEN_SECRET:'synthetic-upgrade-local-status-secret-at-least-32',ORDER_STATUS_READ_ENABLED:'true',CART_QUOTE_ENABLED:'true'};
 let browserToken=auth.token;
 https.on('request',async(req,res)=>{
  try{
   const u=new URL(req.url,'https://127.0.0.1:4319');
   if(u.pathname.startsWith('/v1/')||u.pathname==='/api/menu'){
    let path=u.pathname;if(path==='/api/menu')path='/v1/dashboard/restaurants/'+u.searchParams.get('restaurantId')+'/locations/'+u.searchParams.get('locationId')+'/menu';
    const headers=new Headers(req.headers);if(u.pathname==='/api/menu')headers.set('authorization','Bearer '+browserToken);
    const response=await worker.fetch(new Request('https://127.0.0.1:4319'+path,{method:req.method,headers,...(req.method==='GET'?{}:{body:Readable.toWeb(req),duplex:'half'})}),env);
    res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
   }else vite.middlewares(req,res,()=>{res.statusCode=404;res.end();});
  }catch{res.statusCode=500;res.end();}
 });
 await new Promise((ok,no)=>{https.once('error',no);https.listen(4319,'127.0.0.1',ok);});
 const api=async(path,token,method='GET',body)=>fetch('https://127.0.0.1:4319'+path,{method,headers:{...(token?{authorization:'Bearer '+token}:{}),'content-type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});
 const orders=(r=restaurant,l=location)=>`/v1/dashboard/restaurants/${r}/locations/${l}/orders`;
 const menuPath=`/v1/dashboard/restaurants/${restaurant}/locations/${location}/menu`;
 await caseRun('UP-06-HTTPS-AUTH-API',async()=>{const response=await api(orders(),auth.token);assert.equal(response.status,200);const text=JSON.stringify(await response.json());const old=(await sql.query('select id from upgrade_evidence.orders')).rows;assert.ok(old.every(x=>text.includes(x.id)));});
 await caseRun('UP-05-SCOPES',async()=>{assert.equal((await api(orders(),manager.token)).status,200);assert.equal((await api(orders(),kitchen.token)).status,200);assert.equal((await api(orders(),auth.aal1)).status,403);assert.equal((await api(orders(),foreignAuth.token)).status,403);assert.equal((await api(orders(restaurant,otherSite),manager.token)).status,403);assert.equal((await api(orders())).status,401);});
 await caseRun('UP-05-VIEWER',async()=>{assert.equal((await api(orders(),viewer.token)).status,200);assert.equal((await api(menuPath,viewer.token)).status,403);const oid=(await sql.query('select id from upgrade_evidence.orders where n=2')).rows[0].id;assert.equal((await api(orders()+'/'+oid+'/status',viewer.token,'POST',{expectedStatus:'submitted',targetStatus:'accepted'})).status,403);});
 await caseRun('UP-06-API-REPLAY',async()=>{
  const old=(await sql.query('select id,requested_for from upgrade_evidence.orders where n=2')).rows[0];
  const command={menuId:menu,menuVersionId:version,requestedFor:old.requested_for.toISOString(),lines:[{menuItemId:'e6000000-0000-0000-0000-000000000001',quantity:1}],submissionKey:'premerge-legacy-order-0002',customer:{contactName:'Synthetic Upgrade Guest',phoneE164:'+15555550101',email:'upgrade-2@example.invalid'},privacyNoticeVersion:'upgrade-v1'};
  const before=(await sql.query('select (select count(*) from public.orders) o,(select count(*) from public.order_payments) p,(select count(*) from public.outbox_events) e')).rows[0];
  for(let i=0;i<2;i++){const response=await api('/v1/storefront/upgrade-restaurant-a/upgrade-a-mitte/orders',null,'POST',command);assert.ok([200,201].includes(response.status));assert.ok(JSON.stringify(await response.json()).includes(old.id));}
  assert.deepEqual((await sql.query('select (select count(*) from public.orders) o,(select count(*) from public.order_payments) p,(select count(*) from public.outbox_events) e')).rows[0],before);
 });
 await caseRun('UP-06-REALTIME',async()=>{await realtimeProbe(auth.token,true);await realtimeProbe(kitchen.token,true);await realtimeProbe(foreignAuth.token,false);await realtimeProbe(manager.token,false,'orders:v1:'+restaurant+':'+otherSite);});
 await caseRun('UP-05-RAW-REST',async()=>{const oid=(await sql.query('select id from upgrade_evidence.orders where n=2')).rows[0].id;const r=await fetch(c.url+'/rest/v1/orders?select=id',{headers:{apikey:c.anon}});assert.ok([200,401,403].includes(r.status));if(r.status===200)assert.deepEqual(await r.json(),[]);const write=await fetch(c.url+'/rest/v1/orders?id=eq.'+oid,{method:'PATCH',headers:{apikey:c.anon,authorization:'Bearer '+viewer.token,'content-type':'application/json'},body:JSON.stringify({status:'accepted'})});assert.ok([401,403].includes(write.status));assert.equal((await sql.query('select status from public.orders where id=$1',[oid])).rows[0].status,'submitted');});
 await caseRun('UP-05-SUSPENDED',async()=>{await sql.query("update public.restaurant_memberships set status='suspended' where restaurant_id=$1 and user_id=$2",[restaurant,manager.user.id]);assert.equal((await api(orders(),manager.token)).status,403);await realtimeProbe(manager.token,false);});
 await caseRun('UP-05-REVOKED-VIEWER',async()=>{await sql.query('delete from public.restaurant_membership_locations where restaurant_id=$1 and user_id=$2',[restaurant,viewer.user.id]);assert.equal((await api(orders(),viewer.token)).status,403);await realtimeProbe(viewer.token,false);});
 await caseRun('UP-05-REVOKED-SESSION',async()=>{await sql.query('delete from auth.sessions where id=$1 and user_id=$2',[kitchen.user.session,kitchen.user.id]);assert.equal((await api(orders(),kitchen.token)).status,403);await realtimeProbe(kitchen.token,false);});
 const {chromium,firefox,webkit}=frontRequire('playwright');
 for(const [name,engine] of Object.entries({chromium,firefox,webkit}))await caseRun('UP-07-R12-'+name,async()=>{
  // Each browser uses a real new native session; previous denial is not reset by changing an HTTP mock.
  const bAuth=await login(1,true);browserToken=bAuth.token;
  browser=await engine.launch({headless:true});const ctx=await browser.newContext({viewport:{width:390,height:844}});const page=await ctx.newPage();const errors=[];
  page.on('pageerror',e=>errors.push(e.name));page.on('dialog',d=>d.accept());
  await ctx.route('**/*',route=>{if(new URL(route.request().url()).hostname!=='127.0.0.1'){forbiddenRequests++;return route.abort();}return route.continue();});
  // CA must be trusted by the disposable runner/browser. Strict default TLS validation remains on.
  await page.goto('https://127.0.0.1:4319');
  await page.getByRole('button',{name:'Menüstand laden',exact:true}).click();await page.getByText('Menüstand geladen.',{exact:true}).waitFor();
  const copy=page.getByRole('button',{name:'Als neuen Entwurf kopieren',exact:true});if(await copy.count())await copy.click();
  await page.getByRole('button',{name:'Entwurf speichern',exact:true}).waitFor();
  await page.getByLabel('Änderungsnotiz').fill('MG03 private draft');
  await sql.query('delete from auth.sessions where id=$1 and user_id=$2',[bAuth.user.session,bAuth.user.id]);
  const response=page.waitForResponse(r=>r.url().includes('/api/menu')&&[401,403].includes(r.status()));
  await page.getByRole('button',{name:'Menüstand laden',exact:true}).click();await response;
  await page.waitForFunction(()=>document.querySelectorAll('.menu-editor input,.menu-editor textarea').length===0);
  assert.equal(await page.getByRole('button',{name:'Entwurf speichern',exact:true}).count(),0);
  assert.ok(!(await page.locator('body').innerText()).includes('MG03 private draft'));assert.deepEqual(errors,[]);
  await browser.close();browser=undefined;
 });
 await saveState();
 await caseRun('UP-08-NO-PROVIDER',async()=>assert.equal(forbiddenRequests,0));
}
try{
 await sql.connect();
 if(c.stage==='bootstrap')await bootstrap();else if(c.stage.startsWith('restore-'))await restored();else await upgraded();
 report.status='PASS';
}catch(e){report.status='FAIL';process.exitCode=1;}
finally{
 report.forbidden_requests=forbiddenRequests;
 const actions=[];
 if(browser)actions.push(['browser',()=>browser.close()]);
 for(const [i,client] of clients.entries())actions.push(['realtime-'+i,()=>client.removeAllChannels()]);
 if(vite)actions.push(['vite',()=>vite.close()]);
 if(https)actions.push(['https',()=>new Promise((ok,no)=>https.close(error=>error?no(error):ok()))]);
 actions.push(['sql',()=>sql.end()]);
 report.cleanup=await closeOwnedResources(actions);
 if(report.cleanup.status!=='PASS'){report.status='FAIL';process.exitCode=1;}
 globalThis.fetch=rawFetch;
 await writeFile(c.output,JSON.stringify(report,null,2)+'\n');
}
