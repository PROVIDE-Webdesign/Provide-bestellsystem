-- Prepared native SQL partial proof, NOT EXECUTED. This alone does NOT close MG-03.
begin;
create extension if not exists pgtap with schema extensions;
set local search_path=extensions,public;
select no_plan();
select is((select count(*)::integer from supabase_migrations.schema_migrations),46,'UP-03: 46 original application migration versions applied');
select ok(upgrade_evidence.legacy_rows_match(schema_name,table_name,columns_before,pk,rows_before),
 'UP-04: legacy rows preserved in '||schema_name||'.'||table_name) from upgrade_evidence.baseline;
select is((select count(*)::integer from upgrade_evidence.orders),5,'UP-02: five committed old orders');
select is((select count(*)::integer from public.orders where id in(select id from upgrade_evidence.orders)),5,'UP-04: all five old orders retained');
select is((select count(distinct order_number)::integer from public.orders where id in(select id from upgrade_evidence.orders)),5,'UP-04: five unique backfilled readable order numbers');
select ok(not exists(select 1 from public.orders where id in(select id from upgrade_evidence.orders) and (order_number is null or order_number<=0)),'UP-04: old order numbers positive/non-null');
select ok(not exists(select 1 from public.orders where id in(select id from upgrade_evidence.orders) and tax_summary is not null),'UP-04: no invented retroactive legacy tax snapshot');
select ok(not has_table_privilege('anon','public.orders','SELECT'),'UP-05: anon cannot read order table');
select ok(not has_table_privilege('authenticated','public.orders','INSERT,UPDATE,DELETE'),'UP-05: browser role cannot write order table directly');
select ok(not exists(select 1 from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname in('public','private') and c.relkind='r' and not c.relrowsecurity),'UP-05: all product public/private tables have RLS');
select ok(not exists(select 1 from public.feature_definitions where default_enabled and key in('payment.online','notifications.email','checkout.protection')),'UP-05: named critical defaults are not enabled');

-- Owner A can read own committed orders; owner B cannot read those foreign orders.
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"e1000000-0000-0000-0000-000000000001","role":"authenticated","aal":"aal2","session_id":"PLACEHOLDER_OWNER_SESSION"}',true);
select is((select count(*)::integer from public.orders where submission_key like 'premerge-legacy-order-%'),5,'UP-05: owner A sees own legacy orders');
select set_config('request.jwt.claims','{"sub":"e1000000-0000-0000-0000-000000000005","role":"authenticated","aal":"aal2","session_id":"PLACEHOLDER_FOREIGN_SESSION"}',true);
select is((select count(*)::integer from public.orders where submission_key like 'premerge-legacy-order-%'),0,'UP-05: owner B cannot see owner A orders');
reset role;

-- Replay an old payload through the corrected function. Rejecting the same old request is a real compatibility finding.
select is(private.submit_order_with_payment(
 'e2000000-0000-0000-0000-000000000001','e3000000-0000-0000-0000-000000000001',
 'e4000000-0000-0000-0000-000000000001','e5000000-0000-0000-0000-000000000001',
 'pickup',(select requested_for from upgrade_evidence.orders where n=2),
 '[{"menu_item_id":"e6000000-0000-0000-0000-000000000001","quantity":1}]',
 'premerge-legacy-order-0002',now(),'on_fulfillment'),
 (select id from upgrade_evidence.orders where n=2),'UP-06: replay retains original order id');
select * from finish();
rollback;
