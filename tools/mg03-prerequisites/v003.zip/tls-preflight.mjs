// Native preflight for separately authorized execution. Strict browser/Node CA trust.
import assert from 'node:assert/strict';
import {createServer} from 'node:https';
import {createRequire} from 'node:module';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {closeOwnedResources} from './cleanup.mjs';
const [repo,tls]=process.argv.slice(2);
const require=createRequire(join(repo,'apps/storefront/package.json'));
const {chromium,firefox,webkit}=require('playwright');
const server=createServer({key:await readFile(join(tls,'key.pem')),cert:await readFile(join(tls,'cert.pem'))},(_req,res)=>res.end('MG03 TLS preflight'));
let browser,passed=false;
try{
 await new Promise((ok,no)=>{server.once('error',no);server.listen(4319,'127.0.0.1',ok);});
 assert.equal(await (await fetch('https://127.0.0.1:4319',{redirect:'error'})).text(),'MG03 TLS preflight');
 for(const engine of [chromium,firefox,webkit]){
  browser=await engine.launch({headless:true});const page=await browser.newPage();
  const response=await page.goto('https://127.0.0.1:4319');assert.equal(response.status(),200);
  assert.equal(await page.locator('body').innerText(),'MG03 TLS preflight');
  await browser.close();browser=undefined;
 }
 passed=true;
}finally{
 const actions=[];
 if(browser)actions.push(['browser',()=>browser.close()]);
 actions.push(['tls-server',()=>new Promise((ok,no)=>server.close(error=>error?no(error):ok()))]);
 const cleanup=await closeOwnedResources(actions);
 assert.equal(cleanup.status,'PASS','TLS preflight resource cleanup failed');
}
if(passed)console.log('PASS: strict Node and all three browser TLS checks; resources closed');
